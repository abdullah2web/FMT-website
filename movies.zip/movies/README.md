# Favorite Movies Trailers Website

This website project will named **FMT Website** and contain three python files: 

* entertainment_center
* media
* fresh_tomatoes

## entertainment_center: 

Use this file is _FMT_ website data base links, this file has variables contain movie title, movie poster url and movie trailer url. 
also import media file to use class and functions. 

## media: 

This file contain class and functions reseve the arguments from entertainment_center file,
such as Movies class has _init_ override method and _show trailers_ method.

## fresh_tomatoes: 

This file will run and open html page that contain and show _FMT_ website, and import webbrowser to open page.

there is function named :

```
open_movies_page()

```

### for any assistant, 
please contact me [Here](abdullah2web@gmail.com)

Regards,
