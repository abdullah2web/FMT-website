# Favorite Movies Trailers Website

This website project will named **FMT Website** and contain three python files: 

* entertainment_center
* media
* fresh_tomatoes

## entertainment_center: 

Use this file to run _FMT_ website, this file has variables contain movie title, movie poster url and movie trailer url. 
also import media file to use functions. 

## media: 

This file contain class and functions reseve the arguments from entertainment_center file,
such as Movies class has _init_ override method and _show trailers_ method.

## fresh_tomatoes: 

This file use html page for contain and show _FMT_ website, and import webbrowser to open page 
it is contain function named :

```
open_movies_page()

```

### for any assistant, 
please contact me [Here](abdullah2web@gmail.com)

Regards,
